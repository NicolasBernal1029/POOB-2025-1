import java.awt.*;

/**
 * @author  Juan Daniel Bogotá Fuentes and Nicolas Felipe Bernal Gallo (Modified)
 * @version 1.0  (06 February 2025)
 */

public class Pit{
    
    private int seedsDiameter;
    private int sizeSquare;
    private int xPosition;
    private int yPosition;
    private String seedsColor;
    private String borderColor;
    private String backgroundColor;
    private boolean isVisible;
    private int numberSeeds;
    private Canvas canvas;
    
    /**
     * Constructor de la clase Pit.
     * Crea un hueco cuadrado con fondo para guardar semillas.
     * 
     * @param big Indica si el hueco es grande o pequeño.
     * @param xPosition Posición inicial en X.
     * @param yPosition Posición inicial en Y.
     */
    public Pit(boolean big, int xPosition, int yPosition){
        if (big){
            sizeSquare = 200;
        }  else {
            sizeSquare = 100;
        }
        seedsDiameter = 10;
        xPosition = 70;
        yPosition = 70;
        seedsColor = "red";
        borderColor = "black";
        backgroundColor = "blue";
        isVisible = false;
        numberSeeds = 0;
        this.canvas=Canvas.getCanvas();
    }
    
    /**
     * Hace visible el hueco en la pantalla.
     */
    public void makeVisible(){
        isVisible = true;
        draw();
    }
    
    
    /**
     * Hace invisible el hueco en la pantalla.
     */
    public void makeInvisible(){
        erase();
        isVisible = false;
    }

    
     /**
     * Agrega semillas al hueco.
     * @param seeds Número de semillas a agregar.
     */
    public void putSeeds(int seeds) {
        numberSeeds += seeds;
        draw();
    }
    
    /**
     * Remueve semillas del hueco, asegurándose de no tener menos de 0.
     * @param seeds Número de semillas a quitar.
     */
    public void removeSeeds(int seeds) {
        numberSeeds = Math.max(0, numberSeeds - seeds);
        draw();
    }
    
    /**
     * Devuelve el número actual de semillas en el hueco.
     * @return Número de semillas.
     */public int seeds() {
        return numberSeeds;
    }

    /**
     * Cambia el color de las semillas y el fondo del hueco.
     * @param newColorSeeds Nuevo color de las semillas.
     * @param newBackgroundColor Nuevo color de fondo.
     */
    public void changeColor(String newColorSeeds,String newBackgroundColor){
        seedsColor = newColorSeeds;
        backgroundColor = newBackgroundColor;
        draw();
    }
    
    /**
     * Mueve el hueco a una nueva posición en la pantalla.
     * @param x Nueva posición en el eje X.
     * @param y Nueva posición en el eje Y.
     */
    public void moveTo(int x, int y){
        xPosition = x;
        yPosition = y;
        draw();
    }

    /**
     * Borra el hueco de la pantalla.
     */
    private void erase(){
        if(isVisible) {
            Canvas canvas = Canvas.getCanvas();
            canvas.erase(this);
        }
    }
    
    /**
     * Dibuja el hueco en la pantalla.
     */
     private void draw() {
    if (isVisible) {
        canvas.erase(this); // Borra la caja antes de redibujarla

        // Dibujar el borde (Caja ligeramente más grande)
        int borderThickness = 50; // Grosor del borde
        canvas.draw(new Object(), borderColor,
                new java.awt.Rectangle(xPosition - borderThickness, yPosition - borderThickness,
                        sizeSquare + 2 * borderThickness, sizeSquare + 2 * borderThickness));

        // Dibujar la caja interna (sin borde)
        canvas.draw(this, backgroundColor, new java.awt.Rectangle(xPosition, yPosition, sizeSquare, sizeSquare));

        // Dibujar las semillas
        for (int i = 0; i < numberSeeds; i++) {
            int seedX = xPosition + (i % (sizeSquare / seedsDiameter)) * seedsDiameter;
            int seedY = yPosition + (i / (sizeSquare / seedsDiameter)) * seedsDiameter;
            canvas.draw(new Object(), seedsColor, new java.awt.geom.Ellipse2D.Double(seedX, seedY, seedsDiameter, seedsDiameter));
        }
        }
    }
}
